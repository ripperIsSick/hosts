﻿$SubscriptionName="vikram_iyer"
$StorageAccount=""
$VMName=""
$VMSize="Basic_A3"
$ImageName=""
$UserName=""
$Password=""
$CloudServiceName=""
$ReservedIPName=""
$Location=""

Add-AzureAccount
Select-AzureSubscription -SubscriptionName $SubscriptionName
Set-AzureSubscription -SubscriptionName $SubscriptionName -CurrentStorageAccountName $StorageAccount

#RIP creation

New-AzureVMConfig -Name $VMName -InstanceSize $VMSize -ImageName $ImageName `
| Add-AzureProvisioningConfig -Linux -LinuxUser $UserName -Password $Password `
| New-AzureVM -ServiceName $CloudServiceName -ReservedIPName $ReservedIPName -Location $Location

sleep 60

$VM= Get-AzureVM -ServiceName $CloudServiceName -Name $VMName

Set-AzureEndpoint -Name "SSH" -Protocol tcp -LocalPort 22 -PublicPort 22 -VM $VM | Update-AzureVM